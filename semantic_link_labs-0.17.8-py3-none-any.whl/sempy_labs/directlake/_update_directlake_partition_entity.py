from uuid import UUID
from typing import List, Optional, Union
import json
from sempy._utils._log import log
import sempy_labs._icons as icons
from sempy_labs._refresh_semantic_model import refresh_semantic_model
from sempy_labs.directlake._sources import get_direct_lake_sources
from sempy_labs._helper_functions import (
    _convert_data_type,
    resolve_dataset_name_and_id,
    resolve_workspace_name_and_id,
)


@log
def update_direct_lake_partition_entity(
    dataset: str | UUID,
    table_name: Union[str, List[str]],
    entity_name: Union[str, List[str]],
    schema: Optional[str] = None,
    workspace: Optional[str | UUID] = None,
):
    """
    Remaps a table (or tables) in a Direct Lake semantic model to a table in a lakehouse.

    Parameters
    ----------
    dataset : str | uuid.UUID
        Name or ID of the semantic model.
    table_name : str, typing.List[str]
        Name of the table(s) in the semantic model.
    entity_name : str, typing.List[str]
        Name of the lakehouse table to be mapped to the semantic model table.
    schema : str, default=None
        The schema of the lakehouse table to be mapped to the semantic model table.
        Defaults to None which resolves to the existing schema of the lakehouse table.
    workspace : str | uuid.UUID, default=None
        The Fabric workspace name or ID in which the semantic model exists.
        Defaults to None which resolves to the workspace of the attached lakehouse
        or if no lakehouse attached, resolves to the workspace of the notebook.
    """
    from sempy_labs.tom import connect_semantic_model

    workspace_name, workspace_id = resolve_workspace_name_and_id(workspace)
    dataset_name, dataset_id = resolve_dataset_name_and_id(dataset, workspace_id)

    # Support both str & list types
    if isinstance(table_name, str):
        table_name = [table_name]
    if isinstance(entity_name, str):
        entity_name = [entity_name]

    if len(table_name) != len(entity_name):
        raise ValueError(
            f"{icons.red_dot} The 'table_name' and 'entity_name' arrays must be of equal length."
        )

    icons.sll_tags.append("UpdateDLPartition")

    with connect_semantic_model(
        dataset=dataset_id, readonly=False, workspace=workspace_id
    ) as tom:

        if not tom.is_direct_lake():
            raise ValueError(
                f"{icons.red_dot} The '{dataset_name}' semantic model within the '{workspace_name}' workspace is not in Direct Lake mode."
            )

        for i, tName in enumerate(table_name):
            eName = entity_name[i]
            part_name = next(
                p.Name
                for t in tom.model.Tables
                for p in t.Partitions
                if t.Name == tName
            )
            current_slt = tom.model.Tables[tName].SourceLineageTag

            if part_name is None:
                raise ValueError(
                    f"{icons.red_dot} The '{tName}' table in the '{dataset_name}' semantic model has not been updated."
                )

            tom.model.Tables[tName].Partitions[part_name].Source.EntityName = eName

            # Update source lineage tag
            if schema:
                # Updated to all DL patterns (DLOL, DLSQL)
                tom.model.Tables[tName].Partitions[part_name].Source.SchemaName = schema
                tom.model.Tables[tName].SourceLineageTag = f"[{schema}].[{eName}]"
            else:
                tom.model.Tables[tName].SourceLineageTag = f"[dbo].[{eName}]"

            new_slt = tom.model.Tables[tName].SourceLineageTag

            # PBI_RemovedChildren logic
            try:
                e_name = (
                    tom.model.Tables[tName]
                    .Partitions[part_name]
                    .Source.ExpressionSource.Name
                )
                ann = tom.get_annotation_value(
                    object=tom.model.Expressions[e_name], name="PBI_RemovedChildren"
                )
                if ann:
                    e = json.loads(ann)
                    for i in e:
                        sltag = (
                            i.get("remoteItemId", {})
                            .get("analysisServicesObject", {})
                            .get("sourceLineageTag", {})
                        )
                        if sltag == current_slt:
                            i["remoteItemId"]["analysisServicesObject"][
                                "sourceLineageTag"
                            ] = new_slt
                    tom.set_annotation(
                        object=tom.model.Expressions[e_name],
                        name="PBI_RemovedChildren",
                        value=json.dumps(e),
                    )
            except Exception as e:
                print(
                    f"{icons.yellow_dot} Warning: Could not update PBI_RemovedChildren annotation for table '{tName}'. {str(e)}"
                )

            print(
                f"{icons.green_dot} The '{tName}' table in the '{dataset_name}' semantic model within the '{workspace_name}' workspace has been updated to point to the '{eName}' table."
            )
